<?php
// public/admin/payments.php
// Define APP_BASE_PATH relative to this file's location
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin(); // Ensure admin is logged in

$current_admin_page = 'payments'; // For sidebar highlighting
$page_title = 'จัดการการชำระเงิน'; // Set page title

// --- Filtering Logic ---
// Define possible statuses for the filter dropdown
$allowed_statuses = ['รอตรวจสอบ', 'สำเร็จ', 'ล้มเหลว'];
// Get filter status from query string, default to 'รอตรวจสอบ'
$filter_status = $_GET['status'] ?? 'รอตรวจสอบ';
// If 'all' is requested or the status is invalid, show all (or handle differently)
if ($filter_status === 'all' || !in_array($filter_status, $allowed_statuses)) {
    $filter_status_sql = ''; // No status filter
    $params = [];
} else {
    $filter_status_sql = 'WHERE p.payment_status = ?';
    $params = [$filter_status];
}
// --- End Filtering Logic ---


// Fetch payments data, joining with Orders to get customer info (optional)
try {
    $sql = "SELECT p.*, o.customer_id, o.total_amount as order_total, c.username as customer_username
            FROM Payments p
            JOIN Orders o ON p.order_id = o.order_id
            JOIN Customers c ON o.customer_id = c.customer_id -- Join Customers table
            {$filter_status_sql} -- Apply status filter if set
            ORDER BY p.payment_date DESC"; // Order by most recent payments first

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $payments = $stmt->fetchAll();

} catch (PDOException $e) {
    $payments = []; // Set to empty array on error
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดข้อมูลการชำระเงินได้: ' . $e->getMessage()];
    error_log("Admin Payments Fetch Error: " . $e->getMessage()); // Log the error
}

// Include the admin header
require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php // Include the sidebar ?>
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>

    <div class="flex-grow-1 p-4">
        <h1 class="fs-4 mb-4"><?php echo e($page_title); ?></h1>
        <?php display_alert(); // Show any session messages ?>

        <!-- Filter Form -->
        <form method="get" class="row g-3 mb-3 align-items-center bg-light p-3 rounded border">
            <div class="col-auto">
                 <label for="statusFilter" class="col-form-label fw-bold">กรองตามสถานะ:</label>
            </div>
             <div class="col-md-3">
                <select name="status" id="statusFilter" class="form-select form-select-sm">
                    <option value="all" <?php echo ($filter_status === '' || $filter_status === 'all') ? 'selected' : ''; ?>>-- ทั้งหมด --</option>
                    <?php foreach ($allowed_statuses as $status): ?>
                         <option value="<?php echo e($status); ?>" <?php echo ($filter_status === $status) ? 'selected' : ''; ?>>
                             <?php echo e($status); ?>
                         </option>
                    <?php endforeach; ?>
                </select>
            </div>
             <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">กรอง</button>
            </div>
        </form>
        <!-- End Filter Form -->


        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover caption-top">
                <caption><?php echo count($payments); ?> รายการ <?php echo $filter_status ? '('.e($filter_status).')' : ''; ?></caption>
                <thead class="table-light">
                    <tr>
                        <th>Payment ID</th>
                        <th>Order ID</th>
                        <th>ลูกค้า</th>
                        <th>วันที่แจ้ง</th>
                        <th>จำนวน</th>
                        <th>วิธี</th>
                        <th>หลักฐาน</th>
                        <th>สถานะ</th>
                        <th>จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($payments): ?>
                        <?php foreach ($payments as $payment):
                            // Determine badge color based on status
                            $status_class = 'secondary'; // Default
                            if ($payment['payment_status'] === 'สำเร็จ') $status_class = 'success';
                            if ($payment['payment_status'] === 'ล้มเหลว') $status_class = 'danger';
                            if ($payment['payment_status'] === 'รอตรวจสอบ') $status_class = 'warning';
                        ?>
                            <tr>
                                <td class="font-monospace small"><?php echo e($payment['payment_id']); ?></td>
                                <td><a href="order_details.php?order_id=<?php echo e($payment['order_id']); ?>"><?php echo e($payment['order_id']); ?></a></td>
                                <td><?php echo e($payment['customer_username'] ?? 'N/A'); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($payment['payment_date'])); ?></td>
                                <td class="text-end"><?php echo formatPrice($payment['amount']); ?></td>
                                <td><?php echo e($payment['payment_method']); ?></td>
                                <td class="text-center">
                                    <?php if($payment['payment_evidence']): ?>
                                    <a href="<?php echo BASE_URL . e($payment['payment_evidence']); ?>" target="_blank" class="btn btn-sm btn-outline-info" title="ดูสลิป">
                                        <i class="bi bi-image"></i>
                                    </a>
                                    <?php else: echo '-'; endif; ?>
                                </td>
                                <td><span class="badge text-bg-<?php echo $status_class; ?>"><?php echo e($payment['payment_status']); ?></span></td>
                                <td class="text-center">
                                    <?php // Show Approve/Reject buttons only if status is 'รอตรวจสอบ' ?>
                                    <?php if ($payment['payment_status'] === 'รอตรวจสอบ'): ?>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <form action="payment_process.php" method="POST" class="d-inline" onsubmit="return confirm('ยืนยันการ **อนุมัติ** การชำระเงินนี้?\nระบบจะทำการจัดสรรบัญชีให้ลูกค้าทันที');">
                                                <input type="hidden" name="action" value="approve">
                                                <input type="hidden" name="payment_id" value="<?php echo e($payment['payment_id']); ?>">
                                                <input type="hidden" name="order_id" value="<?php echo e($payment['order_id']); ?>">
                                                <button type="submit" class="btn btn-success" title="อนุมัติ"><i class="bi bi-check-circle-fill"></i></button>
                                            </form>
                                            <form action="payment_process.php" method="POST" class="d-inline" onsubmit="return confirm('ยืนยันการ **ปฏิเสธ** การชำระเงินนี้?');">
                                                 <input type="hidden" name="action" value="reject">
                                                 <input type="hidden" name="payment_id" value="<?php echo e($payment['payment_id']); ?>">
                                                 <input type="hidden" name="order_id" value="<?php echo e($payment['order_id']); ?>">
                                                 <button type="submit" class="btn btn-danger" title="ปฏิเสธ"><i class="bi bi-x-circle-fill"></i></button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted">ไม่พบข้อมูลการชำระเงิน<?php echo $filter_status ? 'ที่ตรงตามเงื่อนไข' : ''; ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div> <!-- /.table-responsive -->

    </div> <!-- /flex-grow-1 -->
</div> <!-- /d-flex -->
<?php
// Include the admin footer
require_once APP_BASE_PATH . '/templates/admin_footer.php';
?>
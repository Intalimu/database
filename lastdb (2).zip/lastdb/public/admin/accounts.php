<?php
// public/admin/accounts.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$current_admin_page = 'accounts';
$page_title = 'จัดการบัญชีสตรีมมิ่ง';

// Fetch accounts with product names
try {
    $stmt = $pdo->query("SELECT sa.*, p.name as product_name
                         FROM StreamingAccounts sa
                         LEFT JOIN Products p ON sa.product_id = p.product_id
                         ORDER BY sa.added_at DESC");
    $accounts = $stmt->fetchAll();
} catch (PDOException $e) {
    $accounts = [];
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดข้อมูลบัญชีได้: ' . $e->getMessage()];
    error_log("Admin Accounts Fetch Error: " . $e->getMessage());
}

require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
             <h1 class="fs-4"><?php echo $page_title; ?></h1>
             <a href="account_form.php" class="btn btn-primary">เพิ่มบัญชีใหม่</a>
        </div>
        <?php display_alert(); ?>

        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Account ID</th>
                        <th>สินค้า</th>
                        <th>Username</th>
                        <th>Password</th> <!-- In real app, hide or mask this -->
                        <th>สถานะ</th>
                        <th>เพิ่มเมื่อ</th>
                        <th>จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($accounts): ?>
                        <?php foreach ($accounts as $account):
                            $status_class = 'secondary';
                            if ($account['status'] === 'พร้อมใช้งาน') $status_class = 'success';
                            if ($account['status'] === 'ถูกใช้งานแล้ว') $status_class = 'info';
                            if ($account['status'] === 'หมดอายุ') $status_class = 'danger';
                        ?>
                            <tr>
                                <td><?php echo e($account['streaming_account_id']); ?></td>
                                <td><?php echo e($account['product_name'] ?? 'N/A'); ?> <small class="text-muted">(<?php echo e($account['product_id']); ?>)</small></td>
                                <td><?php echo e($account['username']); ?></td>
                                <td style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <span title="<?php echo e($account['password']); ?>">***</span> <!-- Mask password for display -->
                                </td>
                                <td><span class="badge text-bg-<?php echo $status_class; ?>"><?php echo e($account['status']); ?></span></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($account['added_at'])); ?></td>
                                <td class="text-center">
    <div class="btn-group btn-group-sm" role="group">
        <?php // --- Edit Button (Now a link) --- ?>
        <a href="account_form.php?id=<?php echo e($account['streaming_account_id']); ?>" class="btn btn-warning" title="แก้ไขบัญชีนี้">
            <i class="bi bi-pencil-fill"></i> แก้ไข
        </a>

        <?php // --- Delete Button (Inside a form) --- ?>
        <form action="account_process.php" method="POST" class="d-inline" onsubmit="return confirm('ต้องการลบบัญชี <?php echo e($account['username']); ?> (<?php echo e($account['streaming_account_id']); ?>) นี้จริงหรือไม่?\n**คำเตือน:** การลบอาจมีผลกระทบ โปรดตรวจสอบให้แน่ใจ!');">
             <input type="hidden" name="action" value="delete"> <?php // ระบุ action เป็น delete ?>
             <input type="hidden" name="streaming_account_id" value="<?php echo e($account['streaming_account_id']); ?>"> <?php // ส่ง ID ที่จะลบ ?>
             <button type="submit" class="btn btn-danger" title="ลบบัญชีนี้">
                 <i class="bi bi-trash-fill"></i> ลบ
             </button>
         </form>
    </div>
</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">ไม่พบข้อมูลบัญชี</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
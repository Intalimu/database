<?php
// public/admin/login.php
// Define APP_BASE_PATH relative to this file's location
define('APP_BASE_PATH', dirname(dirname(__DIR__))); // Go up two levels for base path
require_once APP_BASE_PATH . '/config/db_connect.php';

// Redirect if admin is already logged in
if (isset($_SESSION['admin_id'])) {
    redirect('/admin/'); // Redirect to admin dashboard
}

$page_title = 'Admin Login';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($page_title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        html, body { height: 100%; }
        body { display: flex; align-items: center; padding-top: 40px; padding-bottom: 40px; background-color: #f8f9fa; } /* Lighter background */
        .form-signin { max-width: 380px; padding: 25px; margin: auto; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .form-signin .form-floating:focus-within { z-index: 2; }
        .form-signin input[type="text"] { margin-bottom: -1px; border-bottom-right-radius: 0; border-bottom-left-radius: 0; }
        .form-signin input[type="password"] { margin-bottom: 10px; border-top-left-radius: 0; border-top-right-radius: 0; }
    </style>
</head>
<body class="text-center">
    <main class="form-signin">
        <form action="login_process.php" method="POST">
            <!-- You can add a logo here -->
            <!-- <img class="mb-4" src="/path/to/logo.svg" alt="" width="72" height="57"> -->
            <h1 class="h3 mb-3 fw-normal">Admin Login Panel</h1>

            <?php display_alert(); // Display login errors here ?>

            <div class="form-floating mb-2">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required autofocus>
                <label for="username">Username</label>
            </div>
            <div class="form-floating mb-3">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                <label for="password">Password</label>
            </div>

            <!-- Optional: Remember me checkbox -->
            <!-- <div class="checkbox mb-3">
              <label>
                <input type="checkbox" value="remember-me"> Remember me
              </label>
            </div> -->

            <button class="w-100 btn btn-lg btn-primary" type="submit">เข้าสู่ระบบ</button>
            <p class="mt-5 mb-3 text-muted">© <?php echo date("Y"); ?> Streaming Shop</p>
        </form>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
<?php
// public/admin/categories.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$current_admin_page = 'categories'; // Set identifier for sidebar highlighting (add 'categories' to sidebar links)
$page_title = 'จัดการหมวดหมู่สินค้า';

// Fetch all categories
try {
    $stmt = $pdo->query("SELECT * FROM Categories ORDER BY name ASC");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดข้อมูลหมวดหมู่ได้: ' . $e->getMessage()];
    error_log("Admin Categories Fetch Error: " . $e->getMessage());
}

require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; // Ensure sidebar has a link to categories.php ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
             <h1 class="fs-4"><?php echo e($page_title); ?></h1>
             <a href="category_form.php" class="btn btn-primary"><i class="bi bi-plus-circle"></i> เพิ่มหมวดหมู่ใหม่</a>
        </div>

        <?php display_alert(); ?>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>ชื่อหมวดหมู่</th>
                        <th>คำอธิบาย</th>
                        <th>จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($categories): ?>
                        <?php foreach ($categories as $category): ?>
                            <tr>
                                <td><?php echo e($category['category_id']); ?></td>
                                <td><?php echo e($category['name']); ?></td>
                                <td><?php echo nl2br(e($category['description'] ?? '')); ?></td>
                                <td>
                                    <a href="category_form.php?id=<?php echo e($category['category_id']); ?>" class="btn btn-sm btn-warning" title="แก้ไข"><i class="bi bi-pencil-fill"></i></a>
                                    <form action="category_process.php" method="POST" class="d-inline" onsubmit="return confirm('ต้องการลบหมวดหมู่นี้จริงหรือไม่?\n**คำเตือน:** หากมีสินค้าอยู่ในหมวดหมู่นี้ จะไม่สามารถลบได้');">
                                         <input type="hidden" name="action" value="delete">
                                         <input type="hidden" name="category_id" value="<?php echo e($category['category_id']); ?>">
                                         <button type="submit" class="btn btn-sm btn-danger" title="ลบ"><i class="bi bi-trash-fill"></i></button>
                                     </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted">ไม่พบข้อมูลหมวดหมู่</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
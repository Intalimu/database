<?php
// public/admin/order_details.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$order_id = $_GET['order_id'] ?? null;
if (!$order_id) {
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่ได้ระบุ Order ID'];
    redirect('orders.php');
}

$current_admin_page = 'orders'; // Keep orders highlighted
$page_title = 'รายละเอียด Order: ' . e($order_id);

$order = null;
$order_details = [];
$payments = [];
$allocated_items = []; // For displaying allocated accounts

try {
    // Fetch Order Info + Customer
    $stmt_order = $pdo->prepare("SELECT o.*, c.username as customer_username, c.email as customer_email
                                 FROM Orders o
                                 JOIN Customers c ON o.customer_id = c.customer_id
                                 WHERE o.order_id = ?");
    $stmt_order->execute([$order_id]);
    $order = $stmt_order->fetch();

    if (!$order) {
        $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่พบข้อมูลคำสั่งซื้อ'];
        redirect('orders.php');
    }

    // Fetch Order Details (Items)
    $stmt_details = $pdo->prepare("SELECT od.*, p.name as product_name
                                   FROM OrderDetails od
                                   JOIN Products p ON od.product_id = p.product_id
                                   WHERE od.order_id = ?");
    $stmt_details->execute([$order_id]);
    $order_details = $stmt_details->fetchAll();

    // Fetch Payments for this order
    $stmt_payments = $pdo->prepare("SELECT * FROM Payments WHERE order_id = ? ORDER BY payment_date DESC");
    $stmt_payments->execute([$order_id]);
    $payments = $stmt_payments->fetchAll();

     // Fetch Allocated Items (OrderItems join StreamingAccounts)
     $stmt_items = $pdo->prepare("SELECT oi.order_item_id, oi.order_detail_id, oi.delivered_at,
                                         sa.streaming_account_id, sa.username, sa.password,
                                         od.product_id, p.name as product_name -- Get product name again for clarity
                                  FROM OrderItems oi
                                  JOIN StreamingAccounts sa ON oi.streaming_account_id = sa.streaming_account_id
                                  JOIN OrderDetails od ON oi.order_detail_id = od.order_detail_id
                                  JOIN Products p ON od.product_id = p.product_id
                                  WHERE od.order_id = ?
                                  ORDER BY oi.delivered_at DESC");
      $stmt_items->execute([$order_id]);
      $allocated_items = $stmt_items->fetchAll();


} catch (PDOException $e) {
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการดึงข้อมูล: ' . $e->getMessage()];
    error_log("Admin Order Detail Fetch Error (Order ID: {$order_id}): " . $e->getMessage());
    // Don't redirect, show error on page if possible
}


require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="orders.php">คำสั่งซื้อ</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($order_id); ?></li>
          </ol>
        </nav>

        <h1 class="fs-4 mb-4"><?php echo $page_title; ?></h1>
        <?php display_alert(); ?>

        <?php if ($order): ?>
            <div class="row g-4">
                <!-- Order Summary -->
                <div class="col-lg-6">
                    <div class="card mb-4">
                        <div class="card-header">ข้อมูลคำสั่งซื้อ</div>
                        <div class="card-body">
                             <p><strong>สถานะ:</strong>
                                <?php
                                    $status_class = 'secondary';
                                    if ($order['order_status'] === 'เสร็จสมบูรณ์') $status_class = 'success';
                                    if ($order['order_status'] === 'รอชำระเงิน' || $order['order_status'] === 'รอตรวจสอบการชำระเงิน') $status_class = 'warning';
                                    if (str_contains($order['order_status'], 'ล้มเหลว') || $order['order_status'] === 'ยกเลิก') $status_class = 'danger';
                                    if ($order['order_status'] === 'ชำระเงินแล้ว') $status_class = 'info';
                                ?>
                                <span class="badge text-bg-<?php echo $status_class; ?> fs-6"><?php echo e($order['order_status']); ?></span>
                            </p>
                            <p><strong>วันที่สั่ง:</strong> <?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></p>
                            <p><strong>ลูกค้า:</strong> <?php echo e($order['customer_username']); ?> (<?php echo e($order['customer_id']); ?>)</p>
                            <p><strong>อีเมลลูกค้า:</strong> <?php echo e($order['customer_email']); ?></p>
                            <p><strong>ยอดรวม:</strong> <?php echo formatPrice($order['total_amount']); ?> บาท</p>
                            <!-- Add option to change order status here if needed -->
                        </div>
                    </div>

                     <!-- Payment Info -->
                     <div class="card mb-4">
                         <div class="card-header">ข้อมูลการชำระเงิน</div>
                         <div class="card-body">
                             <?php if($payments): ?>
                                 <?php foreach($payments as $p): ?>
                                     <div class="border-bottom pb-2 mb-2">
                                         <p><strong>Payment ID:</strong> <?php echo e($p['payment_id']); ?></p>
                                         <p><strong>วันที่ชำระ:</strong> <?php echo date('d/m/Y H:i', strtotime($p['payment_date'])); ?></p>
                                         <p><strong>จำนวน:</strong> <?php echo formatPrice($p['amount']); ?> บาท</p>
                                         <p><strong>วิธี:</strong> <?php echo e($p['payment_method']); ?></p>
                                         <p><strong>สถานะ:</strong> <span class="badge text-bg-<?php echo $p['payment_status'] === 'สำเร็จ' ? 'success' : ($p['payment_status'] === 'รอตรวจสอบ' ? 'warning' : 'danger'); ?>"><?php echo e($p['payment_status']); ?></span></p>
                                         <p><strong>หลักฐาน:</strong> <?php echo $p['payment_evidence'] ? '<a href="'.BASE_URL.e($p['payment_evidence']).'" target="_blank">ดูสลิป</a>' : 'N/A'; ?></p>
                                         <?php if($p['transaction_number']): ?><p><strong>Ref No:</strong> <?php echo e($p['transaction_number']); ?></p><?php endif; ?>
                                         <?php if($p['api_transaction_id']): ?><p><strong>API Tx ID:</strong> <?php echo e($p['api_transaction_id']); ?></p><?php endif; ?>
                                         <?php if($p['auto_verified_at']): ?><p><strong>Verified At:</strong> <?php echo date('d/m/Y H:i', strtotime($p['auto_verified_at'])); ?></p><?php endif; ?>

                                         <?php if ($p['payment_status'] === 'รอตรวจสอบ'): ?>
                                             <div class="mt-2">
                                                <form action="payment_process.php" method="POST" class="d-inline" onsubmit="return confirm('ยืนยันการอนุมัติการชำระเงินนี้?');">
                                                    <input type="hidden" name="action" value="approve">
                                                    <input type="hidden" name="payment_id" value="<?php echo e($p['payment_id']); ?>">
                                                    <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">
                                                    <button type="submit" class="btn btn-sm btn-success">อนุมัติ</button>
                                                </form>
                                                <form action="payment_process.php" method="POST" class="d-inline" onsubmit="return confirm('ยืนยันการปฏิเสธการชำระเงินนี้?');">
                                                     <input type="hidden" name="action" value="reject">
                                                     <input type="hidden" name="payment_id" value="<?php echo e($p['payment_id']); ?>">
                                                     <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">
                                                     <button type="submit" class="btn btn-sm btn-danger">ปฏิเสธ</button>
                                                </form>
                                             </div>
                                         <?php endif; ?>

                                     </div>
                                 <?php endforeach; ?>
                             <?php else: ?>
                                 <p class="text-muted">ยังไม่มีข้อมูลการชำระเงินสำหรับคำสั่งซื้อนี้</p>
                             <?php endif; ?>
                         </div>
                     </div>


                </div>

                <!-- Order Details & Items -->
                <div class="col-lg-6">
                    <div class="card mb-4">
                         <div class="card-header">รายการสินค้าที่สั่ง</div>
                         <div class="card-body">
                              <?php if($order_details): ?>
                                <ul class="list-group list-group-flush">
                                <?php foreach($order_details as $detail): ?>
                                    <li class="list-group-item">
                                        <strong><?php echo e($detail['product_name']); ?></strong> (<?php echo e($detail['product_id']); ?>)<br>
                                        จำนวน: <?php echo $detail['quantity']; ?> x <?php echo formatPrice($detail['price_at_order']); ?> = <?php echo formatPrice($detail['subtotal']); ?> บาท
                                    </li>
                                <?php endforeach; ?>
                                </ul>
                              <?php else: ?>
                                <p>ไม่พบรายการสินค้า</p>
                              <?php endif; ?>
                         </div>
                     </div>

                     <div class="card mb-4">
                         <div class="card-header">บัญชีที่จัดสรรแล้ว</div>
                         <div class="card-body">
                            <?php if($allocated_items): ?>
                                <?php foreach($allocated_items as $item): ?>
                                    <div class="border-bottom pb-2 mb-2">
                                        <p><strong>สินค้า:</strong> <?php echo e($item['product_name']); ?> (<?php echo e($item['product_id']); ?>)</p>
                                        <p><strong>Account ID:</strong> <?php echo e($item['streaming_account_id']); ?></p>
                                        <p><strong>Username:</strong> <?php echo e($item['username']); ?></p>
                                        <p><strong>Password:</strong> <span class="text-danger fst-italic">(ดูใน Database โดยตรง)</span></p> <!-- Don't show password even to admin ideally -->
                                        <p><small>จัดสรรเมื่อ: <?php echo date('d/m/Y H:i', strtotime($item['delivered_at'])); ?></small></p>
                                    </div>
                                <?php endforeach; ?>
                            <?php elseif($order['order_status'] === 'เสร็จสมบูรณ์'): ?>
                                 <p class="text-warning">ยังไม่มีข้อมูลบัญชีที่จัดสรร (อาจเกิดข้อผิดพลาดระหว่างจัดสรร)</p>
                            <?php else: ?>
                                 <p class="text-muted">จะแสดงข้อมูลบัญชีเมื่อสถานะเป็น "เสร็จสมบูรณ์"</p>
                            <?php endif; ?>
                         </div>
                     </div>
                </div>
            </div>

        <?php else: ?>
             <div class="alert alert-danger">ไม่พบข้อมูลคำสั่งซื้อที่ระบุ</div>
        <?php endif; ?>

         <a href="orders.php" class="btn btn-outline-secondary mt-3">กลับไปหน้ารายการคำสั่งซื้อ</a>

    </div> <!-- flex-grow-1 -->
</div> <!-- d-flex -->
<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
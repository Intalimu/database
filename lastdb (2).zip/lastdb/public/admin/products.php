<?php
// public/admin/products.php

// --- Essential Setup ---
// 1. Define the Application Base Path relative to this file's location
// (public/admin/ -> go up two levels to the project root)
define('APP_BASE_PATH', dirname(dirname(__DIR__)));

// 2. Include the main configuration and database connection
require_once APP_BASE_PATH . '/config/db_connect.php';

// 3. Ensure the user is an authenticated admin
requireAdminLogin();
// --- End Essential Setup ---


// --- Page Specific Variables ---
$current_admin_page = 'products'; // For sidebar active state highlighting
$page_title = 'จัดการสินค้า';     // For the <title> tag and page heading
// --- End Page Specific Variables ---


// --- Data Fetching ---
// Fetch products with their category names
try {
    // Prepare and execute the query to get all products, joining with categories
    $stmt = $pdo->query("SELECT p.*, c.name as category_name
                         FROM Products p
                         LEFT JOIN Categories c ON p.category_id = c.category_id -- Use LEFT JOIN in case a category is deleted
                         ORDER BY p.product_id DESC"); // Order by most recent product ID first
    $products = $stmt->fetchAll(); // Fetch all results into an array
} catch (PDOException $e) {
    // If database query fails
    $products = []; // Set products to empty array to prevent errors in the view
    // Store an error message in the session to display to the user
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดข้อมูลสินค้าได้: ' . $e->getMessage()];
    // Log the detailed error for the developer/admin
    error_log("Admin Products Fetch Error: " . $e->getMessage());
}
// --- End Data Fetching ---


// --- Include Admin Header Template ---
// This starts the HTML document, includes CSS, and the top navigation bar
require_once APP_BASE_PATH . '/templates/admin_header.php';
?>

<?php // Start of main content area ?>
<div class="d-flex">
    <?php // Include the Sidebar Navigation ?>
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>

    <?php // Main Content Column ?>
    <div class="flex-grow-1 p-4">

        <?php // Page Header with Title and Add Button ?>
        <div class="d-flex justify-content-between align-items-center mb-4">
             <h1 class="fs-4 mb-0"><?php echo e($page_title); ?></h1>
             <a href="product_form.php" class="btn btn-primary"><i class="bi bi-plus-circle"></i> เพิ่มสินค้าใหม่</a>
        </div>

        <?php // Display session alert messages (e.g., success/error after add/edit/delete) ?>
        <?php display_alert(); ?>

        <?php // Table displaying the products ?>
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col" style="width: 60px;">รูปภาพ</th>
                        <th scope="col">ชื่อสินค้า</th>
                        <th scope="col">หมวดหมู่</th>
                        <th scope="col" class="text-end">ราคา (บาท)</th>
                        <th scope="col" class="text-center">สถานะ</th>
                        <th scope="col" class="text-center">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($products): // Check if there are any products to display ?>
                        <?php foreach ($products as $product): // Loop through each product ?>
                            <?php
                                // Determine image URL, use placeholder if not set or invalid
                                $placeholder_img = BASE_URL . '/images/placeholder.png';
                                $img_url = (!empty($product['image_url']))
                                           ? BASE_URL . e($product['image_url'])
                                           : $placeholder_img;

                                // Determine badge color based on status
                                $status_class = 'secondary'; // Default
                                if ($product['status'] === 'พร้อมขาย') $status_class = 'success';
                                if ($product['status'] === 'หมดสต็อก') $status_class = 'warning'; // Changed หมดสต็อก to warning
                                if ($product['status'] === 'ซ่อน') $status_class = 'dark';
                            ?>
                            <tr>
                                <td class="font-monospace small"><?php echo e($product['product_id']); ?></td>
                                <td class="text-center">
                                    <img src="<?php echo $img_url; ?>" alt="<?php echo e($product['name']); ?>" height="40" width="40" style="object-fit: contain;">
                                </td>
                                <td><?php echo e($product['name']); ?></td>
                                <td><?php echo e($product['category_name'] ?? '<span class="text-muted fst-italic">ไม่มี</span>'); ?></td>
                                <td class="text-end"><?php echo formatPrice($product['price']); ?></td>
                                <td class="text-center">
                                    <span class="badge text-bg-<?php echo $status_class; ?>"><?php echo e($product['status']); ?></span>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <?php // Edit Button: Links to the product form with the ID ?>
                                        <a href="product_form.php?id=<?php echo e($product['product_id']); ?>" class="btn btn-warning" title="แก้ไข"><i class="bi bi-pencil-fill"></i></a>

                                        <?php // Delete Button: Submits a form to the process file ?>
                                        <form action="product_process.php" method="POST" class="d-inline" onsubmit="return confirm('ต้องการลบสินค้านี้ (<?php echo e($product['name']); ?>) จริงหรือไม่?\n**คำเตือน:** การกระทำนี้อาจส่งผลต่อข้อมูลอื่น เช่น รายการสั่งซื้อเก่า หรือบัญชีที่เชื่อมโยง');">
                                             <input type="hidden" name="action" value="delete">
                                             <input type="hidden" name="product_id" value="<?php echo e($product['product_id']); ?>">
                                             <button type="submit" class="btn btn-danger" title="ลบ"><i class="bi bi-trash-fill"></i></button>
                                         </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; // End loop through products ?>
                    <?php else: // If no products were found ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">ไม่พบข้อมูลสินค้าในระบบ</td>
                        </tr>
                    <?php endif; // End check for products ?>
                </tbody>
            </table>
        </div> <?php // End table-responsive ?>

    </div> <?php // End flex-grow-1 (Main Content Column) ?>
</div> <?php // End d-flex ?>
<?php // End of main content area ?>

<?php
// --- Include Admin Footer Template ---
// This closes the HTML document and includes JavaScript files
require_once APP_BASE_PATH . '/templates/admin_footer.php';
?>
<?php
// public/admin/account_process.php
// Handles Add, Edit, and Delete actions for Streaming Accounts

// --- Essential Setup ---
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();
// --- End Setup ---

// --- Validate Request Method and Action ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['action'])) {
    // Redirect if not a POST request or action is missing
    redirect('/admin/accounts.php');
}

$action = $_POST['action'];
$redirect_page = '/admin/accounts.php'; // Default redirect page

// --- Start Transaction ---
$pdo->beginTransaction();

try {
    // --- Handle ADD Action ---
    if ($action === 'add') {
        $product_id = $_POST['product_id'] ?? null;
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? ''); // Get password for new account
        $status = $_POST['status'] ?? 'พร้อมใช้งาน';

        // Validation for ADD
        if (empty($product_id) || empty($username) || empty($password) || !in_array($status, ['พร้อมใช้งาน', 'รอตรวจสอบ'])) {
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'กรุณากรอกข้อมูลบัญชี (Add) ให้ครบถ้วนและถูกต้อง (Product, Username, Password, Status)'];
            $redirect_page = 'account_form.php'; // Redirect back to ADD form
            throw new Exception("Validation failed for adding account.");
        }

        $streaming_account_id = generateUniqueID('SA'); // Generate new ID

        // Insert into StreamingAccounts
        $stmt_acc = $pdo->prepare("INSERT INTO StreamingAccounts (streaming_account_id, product_id, username, password, status, added_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt_acc->execute([$streaming_account_id, $product_id, $username, $password, $status]);

        // Insert into StockTransactions if status is 'พร้อมใช้งาน'
        if ($status === 'พร้อมใช้งาน') {
             $stmt_stock = $pdo->prepare("INSERT INTO StockTransactions (product_id, transaction_type, quantity, transaction_time, admin_id) VALUES (?, 'เพิ่ม', 1, NOW(), ?)");
             $stmt_stock->execute([$product_id, $_SESSION['admin_id']]);
        }
        $_SESSION['message'] = ['type' => 'success', 'text' => 'เพิ่มบัญชีสตรีมมิ่ง ID: '.e($streaming_account_id).' สำเร็จแล้ว'];
        $redirect_page = '/admin/accounts.php'; // Redirect to list after successful add

    // --- Handle EDIT Action ---
    } elseif ($action === 'edit') {
        $streaming_account_id = $_POST['streaming_account_id'] ?? null; // Get ID from hidden input
        $product_id = $_POST['product_id'] ?? null;
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? ''); // Password might be empty if not changing
        $status = $_POST['status'] ?? null;

        // Validation for EDIT
        if (empty($streaming_account_id) || empty($product_id) || empty($username) || empty($status) || !in_array($status, ['พร้อมใช้งาน', 'ถูกใช้งานแล้ว', 'หมดอายุ', 'รอตรวจสอบ'])) {
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'กรุณากรอกข้อมูลบัญชี (Edit) ให้ครบถ้วนและถูกต้อง (Product, Username, Status)'];
             $redirect_page = 'account_form.php?id=' . $streaming_account_id; // Redirect back to EDIT form
             throw new Exception("Validation failed for editing account.");
        }

        // Fetch original status to check if stock needs adjustment
        $stmt_old = $pdo->prepare("SELECT status FROM StreamingAccounts WHERE streaming_account_id = ?");
        $stmt_old->execute([$streaming_account_id]);
        $old_status = $stmt_old->fetchColumn();
        if ($old_status === false) { // Account not found
             throw new Exception("ไม่พบบัญชีที่ต้องการแก้ไข (ID: ".e($streaming_account_id).")");
        }


        // Prepare SQL UPDATE statement
        $sql_update = "UPDATE StreamingAccounts SET product_id=?, username=?, status=?, added_at=NOW()"; // Update added_at to reflect modification time
        $params_update = [$product_id, $username, $status];

        // Only include password in the update if a new one was provided
        if (!empty($password)) {
            $sql_update .= ", password=?";
            $params_update[] = $password;
            $_SESSION['message_extra_info'] = ' (รหัสผ่านถูกเปลี่ยน)'; // Optional: add info for success message
        }

        $sql_update .= " WHERE streaming_account_id=?";
        $params_update[] = $streaming_account_id;

        // Execute the update
        $stmt_update = $pdo->prepare($sql_update);
        $stmt_update->execute($params_update);

        // Adjust Stock Transaction based on status change
        if ($old_status === 'พร้อมใช้งาน' && $status !== 'พร้อมใช้งาน') {
            // Was available, now is not -> Decrease stock
            $stmt_stock = $pdo->prepare("INSERT INTO StockTransactions (product_id, transaction_type, quantity, transaction_time, admin_id) VALUES (?, 'แก้ไข (ไม่พร้อม)', -1, NOW(), ?)");
            $stmt_stock->execute([$product_id, $_SESSION['admin_id']]);
        } elseif ($old_status !== 'พร้อมใช้งาน' && $status === 'พร้อมใช้งาน') {
            // Was not available, now is -> Increase stock
             $stmt_stock = $pdo->prepare("INSERT INTO StockTransactions (product_id, transaction_type, quantity, transaction_time, admin_id) VALUES (?, 'แก้ไข (พร้อม)', 1, NOW(), ?)");
             $stmt_stock->execute([$product_id, $_SESSION['admin_id']]);
        }

        $_SESSION['message'] = ['type' => 'success', 'text' => 'แก้ไขบัญชีสตรีมมิ่ง ID: '.e($streaming_account_id).' สำเร็จแล้ว' . ($_SESSION['message_extra_info'] ?? '')];
        unset($_SESSION['message_extra_info']); // Clear extra info
        $redirect_page = '/admin/accounts.php'; // Redirect to list after successful edit


    // --- Handle DELETE Action ---
    } elseif ($action === 'delete') {
        $streaming_account_id = $_POST['streaming_account_id'] ?? null;
        if (!$streaming_account_id) {
             throw new Exception("ไม่ได้ระบุ ID บัญชีที่จะลบ");
        }

        // 1. CRITICAL CHECK: See if account is linked in OrderItems
        $stmt_check_order = $pdo->prepare("SELECT COUNT(*) FROM OrderItems WHERE streaming_account_id = ?");
        $stmt_check_order->execute([$streaming_account_id]);
        if ($stmt_check_order->fetchColumn() > 0) {
            // If linked, prevent deletion and inform admin
            throw new Exception("ไม่สามารถลบบัญชีนี้ได้ เนื่องจากถูกจัดสรรให้กับรายการสั่งซื้อแล้ว");
        }

         // 2. Get info before deleting for stock adjustment
        $stmt_info = $pdo->prepare("SELECT product_id, status FROM StreamingAccounts WHERE streaming_account_id = ?");
        $stmt_info->execute([$streaming_account_id]);
        $acc_info = $stmt_info->fetch();

         // 3. Delete from StreamingAccounts
        $stmt_delete = $pdo->prepare("DELETE FROM StreamingAccounts WHERE streaming_account_id = ?");
        $stmt_delete->execute([$streaming_account_id]);

        // 4. Adjust stock if deletion successful and account was 'พร้อมใช้งาน'
        if ($stmt_delete->rowCount() > 0 && $acc_info) {
             if ($acc_info['status'] === 'พร้อมใช้งาน') {
                 $stmt_stock = $pdo->prepare("INSERT INTO StockTransactions (product_id, transaction_type, quantity, transaction_time, admin_id) VALUES (?, 'ลบ', -1, NOW(), ?)");
                 $stmt_stock->execute([$acc_info['product_id'], $_SESSION['admin_id']]);
             }
             $_SESSION['message'] = ['type' => 'success', 'text' => 'ลบบัญชี (ID: '.e($streaming_account_id).') สำเร็จแล้ว'];
        } else {
            $_SESSION['message'] = ['type' => 'warning', 'text' => 'ไม่พบบัญชีที่ต้องการลบ หรืออาจถูกลบไปแล้ว'];
        }
         $redirect_page = '/admin/accounts.php'; // Redirect to list after delete attempt


    } else {
        // Invalid action value
        throw new Exception("Action ที่ระบุไม่ถูกต้อง: " . e($action));
    }

    // --- Commit Transaction ---
    $pdo->commit();

} catch (PDOException | Exception $e) { // Catch both PDO and general Exceptions
    $pdo->rollBack(); // Rollback on any error
    error_log("Admin Account Process Error (Action: {$action}): " . $e->getMessage());

    // Prepare error message
     if ($e instanceof Exception && str_contains($e->getMessage(), 'จัดสรรให้กับรายการสั่งซื้อแล้ว')) {
         // Specific message for delete failure due to FK
         $_SESSION['message'] = ['type' => 'danger', 'text' => $e->getMessage()];
    } elseif ($e instanceof Exception && str_contains($e->getMessage(), 'Validation failed')) {
        // Validation messages are already set in session, just need to set redirect page
         if ($action === 'edit') {
             $redirect_page = 'account_form.php?id=' . ($_POST['streaming_account_id'] ?? '');
         } else { // add
             $redirect_page = 'account_form.php';
         }
         // No need to set message again if validation failed, it's already set before throwing
    } else {
        // General database or other errors
        $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการประมวลผลข้อมูลบัญชี โปรดลองอีกครั้ง'];
    }

    // Determine redirect page in case of error (if not already set by validation failure)
    if (!isset($redirect_page)) {
        if ($action === 'edit') {
            $redirect_page = 'account_form.php?id=' . ($_POST['streaming_account_id'] ?? '');
        } elseif ($action === 'add') {
            $redirect_page = 'account_form.php';
        } else { // delete or unknown
            $redirect_page = '/admin/accounts.php';
        }
    }
}

// --- Final Redirect ---
redirect($redirect_page); // Redirect to appropriate page
?>
<?php
// public/admin/product_process.php
define('APP_BASE_PATH', dirname(dirname(__DIR__))); // Define APP_BASE_PATH correctly
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $redirect_target = '/admin/products.php'; // Default redirect target

    // Store potential product ID for redirects on error
    $product_id_for_redirect = $_POST['product_id'] ?? null;

    try {
        $pdo->beginTransaction(); // Start transaction for all database operations

        if ($action === 'add' || $action === 'edit') {
            // --- Add or Edit Product ---
            $product_id = $_POST['product_id'] ?? null; // Null for 'add'
            $category_id = $_POST['category_id'] ?? null;
            $name = trim($_POST['name'] ?? '');
            $duration_value = (int)($_POST['duration_value'] ?? 0);
            $description = trim($_POST['description'] ?? '');
            $status = $_POST['status'] ?? 'ซ่อน';
            $price = (float)($_POST['price'] ?? 0.0);
            $image_file = $_FILES['image'] ?? null;
            $current_image_url = $_POST['current_image_url'] ?? null; // For edit

            // Basic Validation
            if (empty($name) || empty($category_id) || $duration_value <= 0 || $price < 0 || !in_array($status, ['พร้อมขาย', 'หมดสต็อก', 'ซ่อน'])) {
                 $_SESSION['message'] = ['type' => 'danger', 'text' => 'กรุณากรอกข้อมูลสินค้าให้ถูกต้องครบถ้วน'];
                 // Set redirect target back to the form on validation error
                 $redirect_target = ($action === 'edit' && $product_id) ? "product_form.php?id=$product_id" : "product_form.php";
                 throw new Exception("Validation Failed"); // Trigger rollback and redirect
            }

            $image_url_to_save = $current_image_url; // Start with current image (for edit)

            // Handle Image Upload (Keep this logic as is)
            if ($image_file && $image_file['error'] === UPLOAD_ERR_OK) {
                // ... (โค้ดจัดการ Upload รูปภาพ เหมือนเดิม) ...
                 $upload_dir = APP_BASE_PATH . '/public/uploads/images/'; // Use APP_BASE_PATH
                 if (!file_exists($upload_dir)) { mkdir($upload_dir, 0775, true); }

                 $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                 $max_size = 2 * 1024 * 1024; // 2MB

                 if (in_array($image_file['type'], $allowed_types) && $image_file['size'] <= $max_size) {
                    $file_extension = pathinfo($image_file['name'], PATHINFO_EXTENSION);
                    // Use a more reliable unique ID generator if possible, but time() is often okay
                    $new_filename = 'prod_' . ($product_id ?: generateUniqueID()) . '_' . time() . '.' . $file_extension;
                    $upload_path = $upload_dir . $new_filename;

                    if (move_uploaded_file($image_file['tmp_name'], $upload_path)) {
                        $image_url_to_save = '/uploads/images/' . $new_filename; // Relative path from public

                        if ($action === 'edit' && $current_image_url && $current_image_url !== $image_url_to_save) {
                            $old_image_path = APP_BASE_PATH . '/public' . $current_image_url;
                            if (file_exists($old_image_path)) { @unlink($old_image_path); }
                        }
                    } else { /* ... handle upload move error ... */ }
                 } else { /* ... handle invalid file type/size ... */ }
            }


            // Prepare and Execute SQL
            if ($action === 'add') {
                $product_id = generateUniqueID('P');
                $sql = "INSERT INTO Products (product_id, category_id, name, duration_value, description, status, price, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $params = [$product_id, $category_id, $name, $duration_value, $description, $status, $price, $image_url_to_save];
                $success_message = 'เพิ่มสินค้า ID: '.e($product_id).' สำเร็จแล้ว';
            } else { // edit
                if (!$product_id) throw new Exception("Product ID is required for editing.");
                $sql = "UPDATE Products SET category_id=?, name=?, duration_value=?, description=?, status=?, price=?, image_url=? WHERE product_id=?";
                $params = [$category_id, $name, $duration_value, $description, $status, $price, $image_url_to_save, $product_id];
                $success_message = 'แก้ไขสินค้า ID: '.e($product_id).' สำเร็จแล้ว';
            }

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            $_SESSION['message'] = ['type' => 'success', 'text' => $success_message];
            $redirect_target = '/admin/products.php'; // Redirect to list on success

        } elseif ($action === 'delete') {
            // --- Delete Product ---
            $product_id = $_POST['product_id'] ?? null;
            if (!$product_id) throw new Exception("Product ID is required for deletion.");

            $product_id_for_redirect = $product_id; // Keep for potential error redirect

            // Optional: Delete associated image file (Keep this logic)
            try { /* ... */ } catch (PDOException $e) { /* Ignore */ }

            // Perform delete
            $stmt = $pdo->prepare("DELETE FROM Products WHERE product_id = ?");
            $stmt->execute([$product_id]);

            if ($stmt->rowCount() > 0) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'ลบสินค้า ID: '.e($product_id).' สำเร็จแล้ว (หากไม่มีข้อมูลเชื่อมโยงอยู่)'];
            } else {
                 $_SESSION['message'] = ['type' => 'warning', 'text' => 'ไม่พบสินค้าที่ต้องการลบ หรืออาจถูกลบไปแล้ว'];
            }
            $redirect_target = '/admin/products.php'; // Redirect to list after delete attempt

        } else {
            throw new Exception("Invalid action specified.");
        }

        // If all operations in 'try' were successful, commit the transaction
        $pdo->commit();

    } catch (PDOException $e) {
        $pdo->rollBack(); // Rollback on database errors
        error_log("Admin Product Process PDO Error (Action: {$action}): " . $e->getMessage());
        if (($e->getCode() == '23000' || $e->errorInfo[1] == 1451) && $action === 'delete') {
             $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถลบสินค้าได้ เนื่องจากมีข้อมูลอื่น (เช่น บัญชี, รายการสั่งซื้อ) เชื่อมโยงอยู่'];
        } else {
             $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดฐานข้อมูล: ' . $e->getMessage()];
        }
        // Determine redirect on error
        $redirect_target = ($action === 'delete' ? '/admin/products.php' : ($action === 'edit' ? "product_form.php?id=$product_id_for_redirect" : "product_form.php")); // *** CORRECTED HERE ***

    } catch (Exception $e) {
        $pdo->rollBack(); // Rollback on general errors (like validation)
        error_log("Admin Product Process General Error (Action: {$action}): " . $e->getMessage());
        $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()];
        // Determine redirect on error
        $redirect_target = ($action === 'delete' ? '/admin/products.php' : ($action === 'edit' ? "product_form.php?id=$product_id_for_redirect" : "product_form.php")); // *** CORRECTED HERE ***
    }

    // Final redirect based on outcome
    redirect($redirect_target);

} else {
    // Redirect if accessed incorrectly
    redirect('/admin/products.php'); // *** CORRECTED HERE ***
}
?>
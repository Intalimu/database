<?php
// public/admin/payment_process.php
// This script handles APPROVING or REJECTING manual payments submitted by users

// Define APP_BASE_PATH relative to this file's location
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php'; // Adjust path as needed
requireAdminLogin(); // Ensure only logged-in admins can access this

// --- Check Request Method and Parameters ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Allow only POST requests
    redirect('/admin/payments.php');
}

if (!isset($_POST['action'], $_POST['payment_id'], $_POST['order_id'])) {
     // Required parameters are missing
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ข้อมูลไม่ครบถ้วนสำหรับการประมวลผล'];
    redirect('/admin/payments.php');
}

$action = $_POST['action']; // 'approve' or 'reject'
$payment_id = $_POST['payment_id'];
$order_id = $_POST['order_id'];

// Validate Payment ID and Order ID format if needed (e.g., regex)

// --- Start Database Transaction ---
// All operations (update payment, update order, allocate accounts) must succeed or fail together.
$pdo->beginTransaction();

try {
    // 1. Verify the payment exists and is in 'รอตรวจสอบ' status. Lock the row for update.
    $pay_stmt = $pdo->prepare("SELECT payment_status FROM Payments WHERE payment_id = ? AND order_id = ? FOR UPDATE");
    $pay_stmt->execute([$payment_id, $order_id]);
    $payment = $pay_stmt->fetch();

    if (!$payment) {
        throw new Exception("ไม่พบการชำระเงิน (Payment ID: {$payment_id}) หรือ Order ID ไม่ตรงกัน");
    }
    if ($payment['payment_status'] !== 'รอตรวจสอบ') {
        throw new Exception("สถานะการชำระเงินไม่ใช่ 'รอตรวจสอบ' (สถานะปัจจุบัน: {$payment['payment_status']})");
    }

    // 2. Process based on action (approve or reject)
    if ($action === 'approve') {
        // --- Approve Path ---

        // 2a. Update Payment Status to 'สำเร็จ'
        $update_pay_stmt = $pdo->prepare("UPDATE Payments SET payment_status = 'สำเร็จ', auto_verified_at = NOW() WHERE payment_id = ?");
        $update_pay_stmt->execute([$payment_id]);
        if ($update_pay_stmt->rowCount() == 0) {
             throw new Exception("ไม่สามารถอัปเดตสถานะ Payment ได้");
        }

        // 2b. Update Order Status to 'ชำระเงินแล้ว' (intermediate state before allocation)
        // Only update if the current status allows (e.g., 'รอตรวจสอบการชำระเงิน')
        $update_order_stmt = $pdo->prepare("UPDATE Orders SET order_status = 'ชำระเงินแล้ว' WHERE order_id = ? AND order_status = 'รอตรวจสอบการชำระเงิน'");
        $update_order_stmt->execute([$order_id]);
        $order_rows_affected = $update_order_stmt->rowCount();

        if ($order_rows_affected == 0) {
             // Order might have been cancelled or already processed - log this unusual case
             // Check current status for better error message
            $current_order_status_stmt = $pdo->prepare("SELECT order_status FROM Orders WHERE order_id = ?");
            $current_order_status_stmt->execute([$order_id]);
            $current_status = $current_order_status_stmt->fetchColumn();
            error_log("Order status not 'รอตรวจสอบการชำระเงิน' for order {$order_id} during payment approval. Current status: {$current_status}.");
            // Decide whether to proceed or rollback. Rollback is safer.
            throw new Exception("ไม่สามารถอัปเดตสถานะ Order เป็น 'ชำระเงินแล้ว' ได้ (สถานะปัจจุบัน: {$current_status})");
        }


        // 2c. *** Allocate Accounts using the function from src/allocation.php ***
        // This function should handle finding, locking, updating accounts, and inserting into OrderItems
        $allocation_success = allocateAccountsForOrder($order_id, $pdo);

        if ($allocation_success) {
            // 2d. If allocation successful, Update Order Status to 'เสร็จสมบูรณ์'
            $update_order_final_stmt = $pdo->prepare("UPDATE Orders SET order_status = 'เสร็จสมบูรณ์' WHERE order_id = ?");
            $update_order_final_stmt->execute([$order_id]);

            $_SESSION['message'] = ['type' => 'success', 'text' => "อนุมัติการชำระเงินและจัดสรรบัญชีสำหรับ Order ID: {$order_id} สำเร็จ"];
             // TODO: Implement customer notification (e.g., via email) about successful allocation

        } else {
            // Allocation failed! This is critical. Transaction will be rolled back.
            // The error should have been logged within allocateAccountsForOrder function.
            throw new Exception("การจัดสรรบัญชีล้มเหลวสำหรับ Order ID: {$order_id}. กรุณาตรวจสอบสต็อกและข้อมูลด่วน!");
        }

    } elseif ($action === 'reject') {
        // --- Reject Path ---

        // 2a. Update Payment Status to 'ล้มเหลว'
        $update_pay_stmt = $pdo->prepare("UPDATE Payments SET payment_status = 'ล้มเหลว' WHERE payment_id = ?");
        $update_pay_stmt->execute([$payment_id]);
         if ($update_pay_stmt->rowCount() == 0) {
             throw new Exception("ไม่สามารถอัปเดตสถานะ Payment เป็น 'ล้มเหลว' ได้");
        }

        // 2b. Update Order Status (e.g., back to 'การชำระเงินล้มเหลว' or maybe 'ยกเลิก')
        // This allows the user to potentially try paying again or cancels the order.
        $update_order_stmt = $pdo->prepare("UPDATE Orders SET order_status = 'การชำระเงินล้มเหลว' WHERE order_id = ?");
        $update_order_stmt->execute([$order_id]);

        $_SESSION['message'] = ['type' => 'warning', 'text' => "ปฏิเสธการชำระเงินสำหรับ Order ID: {$order_id} แล้ว"];
        // TODO: Implement customer notification about payment rejection

    } else {
         // Invalid action value
         throw new Exception("Action ที่ระบุไม่ถูกต้อง ('{$action}')");
    }

    // 3. Commit Transaction if all steps were successful
    $pdo->commit();

} catch (Exception $e) {
    // 4. Rollback Transaction on any error
    $pdo->rollBack();
    // Set error message for admin
    $_SESSION['message'] = ['type' => 'danger', 'text' => "เกิดข้อผิดพลาดในการประมวลผล: " . $e->getMessage()];
    // Log the detailed error
    error_log("Admin Payment Process Error (Payment ID: {$payment_id}, Order ID: {$order_id}, Action: {$action}): " . $e->getMessage());
}

// 5. Redirect back to the payments list page
redirect('/admin/payments.php');
?>
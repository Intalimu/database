<?php
// public/admin/logout.php
// Define APP_BASE_PATH relative to this file's location
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php'; // To start session if not already started

// --- Perform logout actions ---

// 1. Unset specific admin session variables
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
unset($_SESSION['admin_role_id']);

// 2. Optional: Destroy the entire session.
// Be cautious if the same session might be used for customer login on the same browser.
// If only admin uses this domain/path, session_destroy() is safer.
// session_destroy();

// 3. Set a confirmation message (optional)
$_SESSION['message'] = ['type' => 'info', 'text' => 'ออกจากระบบผู้ดูแลเรียบร้อยแล้ว'];

// 4. Redirect to the admin login page
redirect('/admin/login.php');
?>
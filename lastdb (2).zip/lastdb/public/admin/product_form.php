<?php
// public/admin/product_form.php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$current_admin_page = 'products';

$product_id = $_GET['id'] ?? null;
$is_editing = !is_null($product_id);
$page_title = $is_editing ? 'แก้ไขสินค้า' : 'เพิ่มสินค้าใหม่';

$product = [
    'product_id' => '', 'category_id' => '', 'name' => '', 'duration_value' => 30,
    'description' => '', 'status' => 'พร้อมขาย', 'price' => '', 'image_url' => ''
];

// Fetch categories for dropdown
try {
    $cat_stmt = $pdo->query("SELECT category_id, name FROM Categories ORDER BY name");
    $categories = $cat_stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดหมวดหมู่ได้'];
    error_log("Admin Product Form Category Fetch Error: " . $e->getMessage());
    // Don't redirect here, let the form show with an error or empty dropdown
}


if ($is_editing) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM Products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $product_data = $stmt->fetch();
        if ($product_data) {
            $product = $product_data;
        } else {
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่พบสินค้าที่ต้องการแก้ไข'];
            redirect('products.php');
        }
    } catch (PDOException $e) {
         $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการโหลดข้อมูลสินค้า: ' . $e->getMessage()];
         error_log("Admin Edit Product Fetch Error: " . $e->getMessage());
         redirect('products.php');
    }
}

require_once BASE_PATH . '/templates/admin_header.php';
?>

<div class="d-flex">
    <?php require_once BASE_PATH . '/templates/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h1 class="fs-4 mb-4"><?php echo $page_title; ?></h1>
        <?php display_alert(); ?>

        <form action="product_process.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="<?php echo $is_editing ? 'edit' : 'add'; ?>">
            <?php if ($is_editing): ?>
                <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['product_id']); ?>">
            <?php endif; ?>

            <div class="row g-3">
                <div class="col-md-8">
                    <div class="mb-3">
                        <label for="name" class="form-label">ชื่อสินค้า <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                    </div>
                     <div class="mb-3">
                        <label for="description" class="form-label">รายละเอียด</label>
                        <textarea class="form-control" id="description" name="description" rows="4"><?php echo htmlspecialchars($product['description']); ?></textarea>
                    </div>
                </div>
                <div class="col-md-4">
                     <div class="mb-3">
                        <label for="category_id" class="form-label">หมวดหมู่ <span class="text-danger">*</span></label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">-- เลือกหมวดหมู่ --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat['category_id']); ?>" <?php echo ($cat['category_id'] === $product['category_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                     <div class="mb-3">
                        <label for="duration_value" class="form-label">ระยะเวลา (วัน) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="duration_value" name="duration_value" min="1" value="<?php echo htmlspecialchars($product['duration_value']); ?>" required>
                    </div>
                     <div class="mb-3">
                        <label for="price" class="form-label">ราคา <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" min="0" value="<?php echo htmlspecialchars($product['price']); ?>" required>
                    </div>
                     <div class="mb-3">
                        <label for="status" class="form-label">สถานะ <span class="text-danger">*</span></label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="พร้อมขาย" <?php echo ($product['status'] === 'พร้อมขาย') ? 'selected' : ''; ?>>พร้อมขาย</option>
                            <option value="หมดสต็อก" <?php echo ($product['status'] === 'หมดสต็อก') ? 'selected' : ''; ?>>หมดสต็อก</option>
                             <option value="ซ่อน" <?php echo ($product['status'] === 'ซ่อน') ? 'selected' : ''; ?>>ซ่อน (ไม่แสดง)</option>
                        </select>
                    </div>
                     <div class="mb-3">
                        <label for="image" class="form-label">รูปภาพ</label>
                        <input class="form-control" type="file" id="image" name="image" accept="image/png, image/jpeg, image/gif">
                        <?php if ($is_editing && $product['image_url']): ?>
                            <div class="mt-2">
                                <img src="<?php echo BASE_URL . htmlspecialchars($product['image_url']); ?>" height="50" alt="Current Image">
                                <input type="hidden" name="current_image_url" value="<?php echo htmlspecialchars($product['image_url']); ?>">
                                <small class="d-block text-muted">รูปปัจจุบัน</small>
                            </div>
                        <?php endif; ?>
                        <div class="form-text">ปล่อยว่างไว้หากไม่ต้องการเปลี่ยนรูป (ขนาดแนะนำ ...)</div>
                    </div>
                </div>
            </div>

            <hr class="my-4">
            <button type="submit" class="btn btn-primary">บันทึกข้อมูล</button>
            <a href="products.php" class="btn btn-secondary">ยกเลิก</a>
        </form>
    </div>
</div>

<?php require_once BASE_PATH . '/templates/admin_footer.php'; ?>
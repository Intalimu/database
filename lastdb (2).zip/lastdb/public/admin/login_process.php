<?php
// public/admin/login_process.php
// Define APP_BASE_PATH relative to this file's location
define('APP_BASE_PATH', dirname(dirname(__DIR__))); // Go up two levels
require_once APP_BASE_PATH . '/config/db_connect.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get username and password from POST data, trim whitespace
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Basic validation: Check if username or password is empty
    if (empty($username) || empty($password)) {
        $_SESSION['message'] = ['type' => 'danger', 'text' => 'กรุณากรอก Username และ Password'];
        redirect('/admin/login.php'); // Redirect back to login page
    }

    try {
        // Prepare SQL statement to select admin user by username
        $stmt = $pdo->prepare("SELECT admin_id, username, password, role_id FROM Admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(); // Fetch the admin record

        // Verify if admin exists and password is correct using password_verify
        if ($admin && verifyPassword($password, $admin['password'])) {
            // Login successful
            session_regenerate_id(true); // Regenerate session ID to prevent session fixation
            // Store admin information in the session
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_role_id'] = $admin['role_id']; // Store role ID for potential authorization checks later

            // Set a success message (optional)
            // $_SESSION['message'] = ['type' => 'success', 'text' => 'เข้าสู่ระบบผู้ดูแลสำเร็จ'];

            redirect('/admin/'); // Redirect to the admin dashboard

        } else {
            // Invalid credentials (admin not found or password incorrect)
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'Username หรือ Password ไม่ถูกต้อง'];
            redirect('/admin/login.php'); // Redirect back to login page
        }
    } catch (PDOException $e) {
        // Database error during login process
        error_log("Admin Login Error: " . $e->getMessage()); // Log the detailed error
        $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล โปรดลองอีกครั้ง'];
        redirect('/admin/login.php'); // Redirect back to login page
    }
} else {
    // If accessed directly via GET or other methods, redirect to login
    redirect('/admin/login.php');
}
?>
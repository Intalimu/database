<?php
// public/admin/account_form.php
// Handles both Adding and Editing Streaming Accounts

// --- Essential Setup ---
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();
// --- End Setup ---

$current_admin_page = 'accounts'; // For sidebar highlighting

// --- Determine if Editing or Adding ---
$streaming_account_id = $_GET['id'] ?? null; // Get ID from URL parameter ?id=...
$is_editing = !is_null($streaming_account_id); // Check if ID exists
$page_title = $is_editing ? 'แก้ไขบัญชีสตรีมมิ่ง' : 'เพิ่มบัญชีสตรีมมิ่งใหม่'; // Set page title accordingly

// --- Initialize Account Data (Default for Add mode) ---
$account = [
    'streaming_account_id' => '',
    'product_id' => '',
    'username' => '',
    'password' => '', // Password field should be empty by default for security
    'status' => 'พร้อมใช้งาน' // Default status for new accounts
];

// --- Fetch Existing Data if Editing ---
if ($is_editing) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM StreamingAccounts WHERE streaming_account_id = ?");
        $stmt->execute([$streaming_account_id]);
        $account_data = $stmt->fetch();

        if ($account_data) {
            $account = $account_data; // Overwrite default array with fetched data
            // **Important Security Note:** DO NOT pre-fill the password field
            // when editing. Clear it or use separate "Change Password" fields.
            $account['password'] = ''; // Clear password field value for the form
        } else {
            // If account ID from URL is not found in DB, redirect with error
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่พบบัญชีที่ต้องการแก้ไข (ID: ' . e($streaming_account_id) . ')'];
            redirect('/admin/accounts.php'); // Redirect back to the list
        }
    } catch (PDOException $e) {
         // Handle DB error during fetch
         $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการโหลดข้อมูลบัญชี: ' . $e->getMessage()];
         error_log("Admin Edit Account Fetch Error: " . $e->getMessage());
         redirect('/admin/accounts.php'); // Redirect back to the list
    }
}
// --- End Fetch Existing Data ---


// --- Fetch Products for Dropdown (Needed for both Add and Edit) ---
try {
    $prod_stmt = $pdo->query("SELECT product_id, name FROM Products ORDER BY name");
    $products = $prod_stmt->fetchAll();
} catch (PDOException $e) {
    $products = []; // Set empty array on error
    // Set message but allow form to render so user knows there's an issue
    $_SESSION['message'] = ['type' => 'warning', 'text' => 'ไม่สามารถโหลดรายการสินค้าสำหรับเลือกได้'];
    error_log("Admin Account Form Product Fetch Error: " . $e->getMessage());
}
// --- End Fetch Products ---


// --- Include Admin Header ---
require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php // --- Include Sidebar --- ?>
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>

    <?php // --- Main Content --- ?>
    <div class="flex-grow-1 p-4">
        <h1 class="fs-4 mb-4"><?php echo e($page_title); ?></h1>
        <?php display_alert(); // Display success/error messages ?>

        <form action="account_process.php" method="POST">
            <?php // --- Hidden inputs for action and ID (if editing) --- ?>
            <input type="hidden" name="action" value="<?php echo $is_editing ? 'edit' : 'add'; ?>">
            <?php if ($is_editing): ?>
                <input type="hidden" name="streaming_account_id" value="<?php echo e($account['streaming_account_id']); ?>">
            <?php endif; ?>

            <div class="row">
                 <div class="col-md-6">
                     <?php // Display Account ID (disabled) ?>
                     <div class="mb-3">
                        <label for="streaming_account_id_display" class="form-label">Account ID</label>
                        <input type="text" class="form-control" id="streaming_account_id_display" value="<?php echo e($account['streaming_account_id'] ?: '(สร้างอัตโนมัติ)'); ?>" disabled readonly>
                    </div>

                    <?php // Product Selection Dropdown ?>
                     <div class="mb-3">
                        <label for="product_id" class="form-label">สินค้าที่เกี่ยวข้อง <span class="text-danger">*</span></label>
                        <select class="form-select" id="product_id" name="product_id" required>
                            <option value="">-- เลือกสินค้า --</option>
                            <?php foreach ($products as $prod): ?>
                                <?php // Pre-select the current product if editing ?>
                                <option value="<?php echo e($prod['product_id']); ?>" <?php echo ($prod['product_id'] === $account['product_id']) ? 'selected' : ''; ?>>
                                    <?php echo e($prod['name']); ?> (<?php echo e($prod['product_id']); ?>)
                                </option>
                            <?php endforeach; ?>
                            <?php if(empty($products)): ?>
                             <option value="" disabled>ไม่พบข้อมูลสินค้า</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <?php // Username Input ?>
                     <div class="mb-3">
                        <label for="username" class="form-label">Username บัญชี <span class="text-danger">*</span></label>
                        <?php // Pre-fill username if editing ?>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo e($account['username']); ?>" required>
                    </div>

                    <?php // Password Input (Conditional Required) ?>
                     <div class="mb-3">
                        <label for="password" class="form-label">Password บัญชี <?php echo $is_editing ? '<span class="text-muted small">(ปล่อยว่างไว้หากไม่ต้องการเปลี่ยน)</span>' : '<span class="text-danger">*</span>'; ?></label>
                        <input type="text" class="form-control" id="password" name="password" <?php echo !$is_editing ? 'required' : ''; ?>> <?php // Only required when adding ?>
                        <?php if ($is_editing): ?>
                        <div class="form-text text-warning"><i class="bi bi-exclamation-triangle-fill"></i> การเปลี่ยนรหัสผ่านของบัญชีที่ขายไปแล้ว อาจทำให้ลูกค้าเข้าใช้งานไม่ได้</div>
                        <?php endif; ?>
                        <div class="form-text">กรุณาตรวจสอบความถูกต้องก่อนบันทึก</div>
                    </div>

                    <?php // Status Selection Dropdown ?>
                      <div class="mb-3">
                        <label for="status" class="form-label">สถานะ <span class="text-danger">*</span></label>
                        <select class="form-select" id="status" name="status" required>
                            <?php // Pre-select the current status if editing ?>
                            <option value="พร้อมใช้งาน" <?php echo ($account['status'] === 'พร้อมใช้งาน') ? 'selected' : ''; ?>>พร้อมใช้งาน</option>
                            <option value="ถูกใช้งานแล้ว" <?php echo ($account['status'] === 'ถูกใช้งานแล้ว') ? 'selected' : ''; ?>>ถูกใช้งานแล้ว</option>
                            <option value="หมดอายุ" <?php echo ($account['status'] === 'หมดอายุ') ? 'selected' : ''; ?>>หมดอายุ</option>
                            <option value="รอตรวจสอบ" <?php echo ($account['status'] === 'รอตรวจสอบ') ? 'selected' : ''; ?>>รอตรวจสอบ</option>
                        </select>
                    </div>

                    <hr>
                    <?php // Submit and Cancel Buttons ?>
                     <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> บันทึกข้อมูล</button>
                     <a href="accounts.php" class="btn btn-secondary">ยกเลิก</a>
                 </div>
            </div>
        </form>
    </div> <?php // End flex-grow-1 ?>
</div> <?php // End d-flex ?>

<?php // --- Include Admin Footer --- ?>
<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
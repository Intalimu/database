<?php
// public/admin/category_form.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$current_admin_page = 'categories'; // For sidebar highlighting

// Determine if editing or adding
$category_id = $_GET['id'] ?? null;
$is_editing = !is_null($category_id);
$page_title = $is_editing ? 'แก้ไขหมวดหมู่' : 'เพิ่มหมวดหมู่ใหม่';

// Initialize category data array
$category = ['category_id' => '', 'name' => '', 'description' => ''];

// If editing, fetch the existing category data
if ($is_editing) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM Categories WHERE category_id = ?");
        $stmt->execute([$category_id]);
        $category_data = $stmt->fetch();
        if ($category_data) {
            $category = $category_data; // Overwrite default array with fetched data
        } else {
            // Category not found, redirect back with error
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่พบหมวดหมู่ที่ต้องการแก้ไข (ID: ' . e($category_id) . ')'];
            redirect('categories.php');
        }
    } catch (PDOException $e) {
         $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการโหลดข้อมูลหมวดหมู่: ' . $e->getMessage()];
         error_log("Admin Edit Category Fetch Error: " . $e->getMessage());
         redirect('categories.php');
    }
}

require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="categories.php">หมวดหมู่</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $page_title; ?></li>
          </ol>
        </nav>

        <h1 class="fs-4 mb-4"><?php echo $page_title; ?></h1>
        <?php display_alert(); ?>

        <div class="row">
            <div class="col-md-8 col-lg-6">
                <form action="category_process.php" method="POST">
                    <?php // Hidden fields to indicate action and ID (if editing) ?>
                    <input type="hidden" name="action" value="<?php echo $is_editing ? 'edit' : 'add'; ?>">
                    <?php if ($is_editing): ?>
                        <input type="hidden" name="category_id" value="<?php echo e($category['category_id']); ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="category_id_display" class="form-label">Category ID</label>
                        <input type="text" class="form-control" id="category_id_display" value="<?php echo e($category['category_id'] ?: '(สร้างอัตโนมัติ)'); ?>" disabled>
                         <div class="form-text">ระบบจะสร้าง ID ให้เองตอนเพิ่ม (เช่น CATXXX).</div>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">ชื่อหมวดหมู่ <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($category['name']); ?>" required>
                    </div>

                     <div class="mb-3">
                        <label for="description" class="form-label">คำอธิบาย</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo e($category['description']); ?></textarea>
                    </div>

                    <hr>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> บันทึกข้อมูล</button>
                    <a href="categories.php" class="btn btn-secondary">ยกเลิก</a>
                </form>
            </div>
        </div>

    </div>
</div>
<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
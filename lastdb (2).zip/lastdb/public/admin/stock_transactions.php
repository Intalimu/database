<?php
// public/admin/stock_transactions.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$current_admin_page = 'stock';
$page_title = 'ประวัติการเปลี่ยนแปลงสต็อก';

// Fetch stock transactions with product and admin names
try {
    $stmt = $pdo->query("SELECT st.*, p.name as product_name, a.username as admin_username
                         FROM StockTransactions st
                         LEFT JOIN Products p ON st.product_id = p.product_id
                         LEFT JOIN Admins a ON st.admin_id = a.admin_id
                         ORDER BY st.transaction_time DESC");
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $transactions = [];
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดประวัติสต็อกได้: ' . $e->getMessage()];
    error_log("Admin Stock Tx Fetch Error: " . $e->getMessage());
}

require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h1 class="fs-4 mb-4"><?php echo $page_title; ?></h1>
        <?php display_alert(); ?>

        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Tx ID</th>
                        <th>เวลา</th>
                        <th>สินค้า</th>
                        <th>ประเภท</th>
                        <th>จำนวน</th>
                        <th>ผู้ดำเนินการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($transactions): ?>
                        <?php foreach ($transactions as $tx):
                            $type_class = 'secondary';
                            $quantity_display = $tx['quantity'];
                            if ($tx['transaction_type'] === 'เพิ่ม') { $type_class = 'success'; $quantity_display = '+' . $tx['quantity']; }
                            if ($tx['transaction_type'] === 'ลด') { $type_class = 'danger'; $quantity_display = '-' . abs($tx['quantity']); }
                            if ($tx['transaction_type'] === 'ขายออนไลน์') { $type_class = 'info'; $quantity_display = '-' . abs($tx['quantity']); }
                         ?>
                            <tr>
                                <td><?php echo $tx['transaction_id']; ?></td>
                                <td><?php echo date('d/m/Y H:i:s', strtotime($tx['transaction_time'])); ?></td>
                                <td><?php echo e($tx['product_name'] ?? 'N/A'); ?> <small class="text-muted">(<?php echo e($tx['product_id']); ?>)</small></td>
                                <td><span class="badge text-bg-<?php echo $type_class; ?>"><?php echo e($tx['transaction_type']); ?></span></td>
                                <td class="text-end fw-bold"><?php echo $quantity_display; ?></td>
                                <td><?php echo e($tx['admin_username'] ?? 'N/A'); ?> <small class="text-muted">(<?php echo e($tx['admin_id']); ?>)</small></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">ไม่พบข้อมูลประวัติสต็อก</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
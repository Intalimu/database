<?php
// public/admin/category_process.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['action'])) {
    redirect('categories.php');
}

$action = $_POST['action'];

try {
    $pdo->beginTransaction(); // Start transaction for safety, especially for delete

    if ($action === 'add' || $action === 'edit') {
        // --- Add or Edit Category ---
        $category_id = $_POST['category_id'] ?? null; // Null for 'add'
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');

        // Basic Validation
        if (empty($name)) {
             $_SESSION['message'] = ['type' => 'danger', 'text' => 'กรุณากรอกชื่อหมวดหมู่'];
             redirect($action === 'edit' ? "category_form.php?id=$category_id" : "category_form.php");
        }

        // Check for duplicate name (optional but recommended)
        $sql_check = "SELECT category_id FROM Categories WHERE name = ?";
        $params_check = [$name];
        if ($is_editing = ($action === 'edit' && $category_id)) {
            $sql_check .= " AND category_id != ?";
            $params_check[] = $category_id;
        }
        $stmt_check = $pdo->prepare($sql_check);
        $stmt_check->execute($params_check);
        if ($stmt_check->fetch()) {
            $_SESSION['message'] = ['type' => 'danger', 'text' => 'ชื่อหมวดหมู่นี้มีอยู่แล้ว'];
            redirect($is_editing ? "category_form.php?id=$category_id" : "category_form.php");
        }


        // Prepare SQL
        if ($action === 'add') {
            $category_id = generateUniqueID('CAT'); // Generate new ID
            $sql = "INSERT INTO Categories (category_id, name, description) VALUES (?, ?, ?)";
            $params = [$category_id, $name, $description];
            $success_message = 'เพิ่มหมวดหมู่สำเร็จแล้ว';
        } else { // edit
            if (!$category_id) throw new Exception("Category ID is required for editing.");
            $sql = "UPDATE Categories SET name = ?, description = ? WHERE category_id = ?";
            $params = [$name, $description, $category_id];
            $success_message = 'แก้ไขหมวดหมู่สำเร็จแล้ว';
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $_SESSION['message'] = ['type' => 'success', 'text' => $success_message];

    } elseif ($action === 'delete') {
        // --- Delete Category ---
        $category_id = $_POST['category_id'] ?? null;
        if (!$category_id) throw new Exception("Category ID is required for deletion.");

        // IMPORTANT: Attempt to delete. This will FAIL if products are using this category
        // due to the Foreign Key constraint (assuming default RESTRICT behavior).
        // The PDOException caught below will handle this.
        $stmt = $pdo->prepare("DELETE FROM Categories WHERE category_id = ?");
        $stmt->execute([$category_id]);

         if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'ลบหมวดหมู่ (ID: '.e($category_id).') สำเร็จแล้ว'];
        } else {
             $_SESSION['message'] = ['type' => 'warning', 'text' => 'ไม่พบหมวดหมู่ที่ต้องการลบ หรืออาจถูกลบไปแล้ว'];
        }


    } else {
        throw new Exception("Invalid action specified.");
    }

    $pdo->commit(); // Commit transaction if all steps successful

} catch (PDOException $e) {
    $pdo->rollBack(); // Rollback on any error
    error_log("Admin Category Process Error: " . $e->getMessage());
    // Check for foreign key constraint violation (Error code 1451 in MySQL)
    if (($e->getCode() == '23000' || $e->errorInfo[1] == 1451) && $action === 'delete') {
         $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถลบหมวดหมู่ได้ เนื่องจากมีสินค้าอย่างน้อยหนึ่งรายการยังคงใช้หมวดหมู่นี้อยู่'];
    } else {
         $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาดในการประมวลผลข้อมูลหมวดหมู่: ' . $e->getMessage()];
    }
} catch (Exception $e) {
     $pdo->rollBack(); // Rollback on general errors too
     error_log("Admin Category Process General Error: " . $e->getMessage());
     $_SESSION['message'] = ['type' => 'danger', 'text' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()];
}

// Redirect back to the category list page
redirect('categories.php');
?>
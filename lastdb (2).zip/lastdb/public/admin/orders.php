<?php
// public/admin/orders.php
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin();

$current_admin_page = 'orders';
$page_title = 'จัดการคำสั่งซื้อ';

// Fetch orders, maybe join with customers
try {
    $stmt = $pdo->query("SELECT o.order_id, o.order_date, o.order_status, o.total_amount, c.username as customer_username, c.customer_id
                         FROM Orders o
                         JOIN Customers c ON o.customer_id = c.customer_id
                         ORDER BY o.order_date DESC");
    $orders = $stmt->fetchAll();
} catch (PDOException $e) {
    $orders = [];
    $_SESSION['message'] = ['type' => 'danger', 'text' => 'ไม่สามารถโหลดข้อมูลคำสั่งซื้อได้: ' . $e->getMessage()];
    error_log("Admin Orders Fetch Error: " . $e->getMessage());
}

require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h1 class="fs-4 mb-4"><?php echo $page_title; ?></h1>
        <?php display_alert(); ?>

        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Order ID</th>
                        <th>ลูกค้า</th>
                        <th>วันที่สั่ง</th>
                        <th>ยอดรวม</th>
                        <th>สถานะ</th>
                        <th>ดูรายละเอียด</th>
                    </tr>
                </thead>
                <tbody>
                     <?php if ($orders): ?>
                        <?php foreach ($orders as $order):
                            $status_class = 'secondary';
                            if ($order['order_status'] === 'เสร็จสมบูรณ์') $status_class = 'success';
                            if ($order['order_status'] === 'รอชำระเงิน' || $order['order_status'] === 'รอตรวจสอบการชำระเงิน') $status_class = 'warning';
                            if (str_contains($order['order_status'], 'ล้มเหลว') || $order['order_status'] === 'ยกเลิก') $status_class = 'danger';
                            if ($order['order_status'] === 'ชำระเงินแล้ว') $status_class = 'info';
                        ?>
                        <tr>
                            <td><?php echo e($order['order_id']); ?></td>
                            <td><?php echo e($order['customer_username']); ?> <small class="text-muted">(<?php echo e($order['customer_id']); ?>)</small></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                            <td class="text-end"><?php echo formatPrice($order['total_amount']); ?></td>
                             <td><span class="badge text-bg-<?php echo $status_class; ?>"><?php echo e($order['order_status']); ?></span></td>
                             <td>
                                 <a href="order_details.php?order_id=<?php echo e($order['order_id']); ?>" class="btn btn-sm btn-info">รายละเอียด</a>
                             </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">ไม่พบข้อมูลคำสั่งซื้อ</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
<?php require_once APP_BASE_PATH . '/templates/admin_footer.php'; ?>
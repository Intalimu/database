<?php
// public/admin/index.php
// Define APP_BASE_PATH relative to this file's location
define('APP_BASE_PATH', dirname(dirname(__DIR__)));
require_once APP_BASE_PATH . '/config/db_connect.php';
requireAdminLogin(); // Make sure admin is logged in

$current_admin_page = 'dashboard'; // For sidebar highlighting
$page_title = 'Dashboard'; // Set the page title

// Example: Get some basic statistics for the dashboard
try {
    // Count payments waiting for verification
    $pending_payments_count = $pdo->query("SELECT COUNT(*) FROM Payments WHERE payment_status = 'รอตรวจสอบ'")->fetchColumn();

    // Count orders that are not yet completed (pending payment, pending verification, or paid but not allocated)
    $pending_orders_count = $pdo->query("SELECT COUNT(*) FROM Orders WHERE order_status NOT IN ('เสร็จสมบูรณ์', 'ยกเลิก', 'การชำระเงินล้มเหลว')")->fetchColumn();

    // Example: Count products low on stock (e.g., < 3 available accounts)
    // This query might be complex/slow, consider optimizing or doing it differently in production
    $low_stock_threshold = 3;
    $low_stock_stmt = $pdo->prepare("
        SELECT COUNT(p.product_id)
        FROM Products p
        WHERE p.status = 'พร้อมขาย' AND (
            SELECT COUNT(*)
            FROM StreamingAccounts sa
            WHERE sa.product_id = p.product_id AND sa.status = 'พร้อมใช้งาน'
        ) < ?
    ");
    $low_stock_stmt->execute([$low_stock_threshold]);
    $low_stock_count = $low_stock_stmt->fetchColumn();

} catch (PDOException $e) {
    // Set defaults if stats query fails
    $pending_payments_count = 'N/A';
    $pending_orders_count = 'N/A';
    $low_stock_count = 'N/A';
    // Log the error for debugging
    error_log("Admin Dashboard Stat Error: ".$e->getMessage());
    // Optionally set a session message to inform admin about the error
    // $_SESSION['message'] = ['type' => 'warning', 'text' => 'ไม่สามารถโหลดข้อมูลสถิติบางส่วนได้'];
}


// Include the admin header template
require_once APP_BASE_PATH . '/templates/admin_header.php';
?>
<div class="d-flex">
    <?php // Include the sidebar template ?>
    <?php require_once APP_BASE_PATH . '/templates/sidebar.php'; ?>

    <div class="flex-grow-1 p-4">
        <h1 class="fs-4 mb-4"><?php echo e($page_title); ?></h1>
        <?php display_alert(); // Display any session messages (like login success) ?>

        <div class="row g-4">
            <div class="col-md-6 col-xl-4">
                <div class="card text-bg-warning shadow-sm h-100">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0"><?php echo $pending_payments_count; ?></h5>
                            <i class="bi bi-hourglass-split fs-3 text-white-50"></i>
                        </div>
                        <p class="card-text">รายการรอตรวจสอบชำระเงิน</p>
                        <a href="payments.php?status=รอตรวจสอบ" class="btn btn-sm btn-outline-light mt-auto stretched-link">ดูรายการ <i class="bi bi-arrow-right-short"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                 <div class="card text-bg-info shadow-sm h-100">
                     <div class="card-body d-flex flex-column">
                          <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0"><?php echo $pending_orders_count; ?></h5>
                             <i class="bi bi-box-seam fs-3 text-white-50"></i>
                        </div>
                        <p class="card-text">คำสั่งซื้อรอดำเนินการ</p>
                        <a href="orders.php" class="btn btn-sm btn-outline-light mt-auto stretched-link">ดูรายการ <i class="bi bi-arrow-right-short"></i></a>
                    </div>
                </div>
            </div>
             <div class="col-md-6 col-xl-4">
                 <div class="card text-bg-danger shadow-sm h-100">
                     <div class="card-body d-flex flex-column">
                          <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0"><?php echo $low_stock_count; ?></h5>
                             <i class="bi bi-exclamation-triangle fs-3 text-white-50"></i>
                        </div>
                        <p class="card-text">สินค้าสต็อกเหลือน้อย (น้อยกว่า <?php echo $low_stock_threshold; ?>)</p>
                        <a href="accounts.php" class="btn btn-sm btn-outline-light mt-auto stretched-link">ดูสต็อก <i class="bi bi-arrow-right-short"></i></a>
                    </div>
                </div>
            </div>
            <!-- Add more cards for other stats like total users, total products etc. -->
        </div>

        <!-- Add more dashboard content sections here, e.g., recent orders, quick links -->
        <div class="mt-5">
            <h4>ลิงก์ด่วน</h4>
            <div class="list-group">
                <a href="product_form.php" class="list-group-item list-group-item-action">เพิ่มสินค้าใหม่</a>
                <a href="account_form.php" class="list-group-item list-group-item-action">เพิ่มบัญชีใหม่</a>
                <a href="orders.php" class="list-group-item list-group-item-action">ดูคำสั่งซื้อทั้งหมด</a>
            </div>
        </div>

    </div> <!-- /flex-grow-1 -->
</div> <!-- /d-flex -->

<?php
// Include the admin footer template
require_once APP_BASE_PATH . '/templates/admin_footer.php';
?>